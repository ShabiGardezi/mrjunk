"use strict";
exports.id = 92;
exports.ids = [92];
exports.modules = {

/***/ 4092:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  Z: () => (/* binding */ header_1)
});

// EXTERNAL MODULE: ./node_modules/react/jsx-runtime.js
var jsx_runtime = __webpack_require__(5893);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
var link_default = /*#__PURE__*/__webpack_require__.n(next_link);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(5675);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
// EXTERNAL MODULE: external "react-icons/fa"
var fa_ = __webpack_require__(6290);
// EXTERNAL MODULE: external "react-icons/ai"
var ai_ = __webpack_require__(9847);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: external "next/router"
var router_ = __webpack_require__(1853);
// EXTERNAL MODULE: ./src/components/header/offcanvas-data.js
var offcanvas_data = __webpack_require__(6811);
;// CONCATENATED MODULE: ./src/components/header/white-logo.js



function WhiteLogo() {
    return /*#__PURE__*/ jsx_runtime.jsx((link_default()), {
        href: "/",
        className: "inline-block align-middle leading-[1] mt-2",
        children: /*#__PURE__*/ jsx_runtime.jsx((image_default()), {
            src: "/logos/logo.webp",
            alt: "Logo",
            width: 250,
            height: 150
        })
    });
}
/* harmony default export */ const white_logo = (WhiteLogo);

;// CONCATENATED MODULE: ./src/components/header/header-1.js









function HeaderOne() {
    const [offcanvas, setOffcanvas] = (0,external_react_.useState)(false);
    const [servicesOpen, setServicesOpen] = (0,external_react_.useState)(false) // Initialize to false
    ;
    const showOffcanvas = ()=>setOffcanvas(!offcanvas);
    const router = (0,router_.useRouter)();
    (0,external_react_.useEffect)(()=>{
        window.addEventListener("scroll", isSticky);
        return ()=>{
            window.removeEventListener("scroll", isSticky);
        };
    });
    const isSticky = (e)=>{
        const header = document.querySelector(".header-section");
        const scrollTop = window.scrollY;
        scrollTop >= 250 ? header.classList.add("is-sticky") : header.classList.remove("is-sticky");
    };
    const headerCss = `flex lg:justify-between justify-end items-center`;
    return /*#__PURE__*/ (0,jsx_runtime.jsxs)(external_react_.Fragment, {
        children: [
            /*#__PURE__*/ jsx_runtime.jsx("header", {
                className: "absolute w-full z-10",
                children: /*#__PURE__*/ jsx_runtime.jsx("div", {
                    className: "sticky-holder header-section sticky-style-1",
                    children: /*#__PURE__*/ jsx_runtime.jsx("div", {
                        className: "custom-container container",
                        children: /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                            className: "grid grid-cols-12 items-center leading-[120px]",
                            children: [
                                /*#__PURE__*/ jsx_runtime.jsx("div", {
                                    className: "lg:col-span-3 col-span-6 mr-4",
                                    children: /*#__PURE__*/ jsx_runtime.jsx(white_logo, {})
                                }),
                                /*#__PURE__*/ jsx_runtime.jsx("div", {
                                    className: "lg:col-span-6 lg:block hidden ml-3",
                                    children: /*#__PURE__*/ jsx_runtime.jsx("nav", {
                                        children: /*#__PURE__*/ (0,jsx_runtime.jsxs)("ul", {
                                            className: "main-menu text-white",
                                            children: [
                                                /*#__PURE__*/ jsx_runtime.jsx("li", {
                                                    className: router.pathname == "/" ? "active" : "",
                                                    children: /*#__PURE__*/ jsx_runtime.jsx((link_default()), {
                                                        href: "/",
                                                        children: /*#__PURE__*/ jsx_runtime.jsx("span", {
                                                            className: "transition-transform duration-300 hover:scale-90",
                                                            children: "Home"
                                                        })
                                                    })
                                                }),
                                                /*#__PURE__*/ jsx_runtime.jsx("li", {
                                                    className: router.pathname == "/about" ? "active" : "",
                                                    children: /*#__PURE__*/ jsx_runtime.jsx((link_default()), {
                                                        href: "#about",
                                                        children: /*#__PURE__*/ jsx_runtime.jsx("span", {
                                                            children: "About"
                                                        })
                                                    })
                                                }),
                                                /*#__PURE__*/ (0,jsx_runtime.jsxs)("li", {
                                                    onMouseEnter: ()=>setServicesOpen(true),
                                                    onMouseLeave: ()=>setServicesOpen(false),
                                                    className: router.pathname.startsWith("/services") ? "active" : "",
                                                    children: [
                                                        /*#__PURE__*/ jsx_runtime.jsx((link_default()), {
                                                            href: "#services",
                                                            children: /*#__PURE__*/ jsx_runtime.jsx("span", {
                                                                children: "Services"
                                                            })
                                                        }),
                                                        servicesOpen && /*#__PURE__*/ jsx_runtime.jsx("ul", {
                                                            className: "sub-menu",
                                                            children: offcanvas_data/* OffcanvasData */.A.find((item)=>item.title === "Services").subcategories.slice(0, 3).map((subcategory, subIndex)=>/*#__PURE__*/ jsx_runtime.jsx("li", {
                                                                    className: router.pathname.startsWith(subcategory.path) ? "active" : "",
                                                                    children: /*#__PURE__*/ jsx_runtime.jsx((link_default()), {
                                                                        href: subcategory.path,
                                                                        children: /*#__PURE__*/ jsx_runtime.jsx("span", {
                                                                            className: "transition-transform duration-300 hover:text-lg",
                                                                            children: subcategory.title
                                                                        })
                                                                    })
                                                                }, subIndex))
                                                        })
                                                    ]
                                                }),
                                                /*#__PURE__*/ jsx_runtime.jsx("li", {
                                                    className: router.pathname == "/posts" ? "active" : "",
                                                    children: /*#__PURE__*/ jsx_runtime.jsx((link_default()), {
                                                        href: "#testimonials",
                                                        children: /*#__PURE__*/ jsx_runtime.jsx("span", {
                                                            children: "Testimonials"
                                                        })
                                                    })
                                                }),
                                                /*#__PURE__*/ jsx_runtime.jsx("li", {
                                                    className: router.pathname == "/posts" ? "active" : "",
                                                    children: /*#__PURE__*/ jsx_runtime.jsx("a", {
                                                        href: "mailto:dan@mrjunkaway.com",
                                                        children: /*#__PURE__*/ jsx_runtime.jsx("span", {
                                                            children: "Request Quote"
                                                        })
                                                    })
                                                }),
                                                /*#__PURE__*/ jsx_runtime.jsx("li", {
                                                    className: router.pathname == "/contact" ? "active" : "",
                                                    children: /*#__PURE__*/ jsx_runtime.jsx((link_default()), {
                                                        href: "#footer",
                                                        children: /*#__PURE__*/ jsx_runtime.jsx("span", {
                                                            children: "Contact"
                                                        })
                                                    })
                                                })
                                            ]
                                        })
                                    })
                                }),
                                /*#__PURE__*/ jsx_runtime.jsx("div", {
                                    className: "lg:col-span-3 col-span-6",
                                    children: /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                                        className: `outer-box ${headerCss}`,
                                        children: [
                                            /*#__PURE__*/ (0,jsx_runtime.jsxs)("ul", {
                                                className: "language-list text-white",
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime.jsx("li", {}),
                                                    /*#__PURE__*/ jsx_runtime.jsx("li", {})
                                                ]
                                            }),
                                            /*#__PURE__*/ jsx_runtime.jsx("div", {
                                                className: "offcanvas-area",
                                                children: /*#__PURE__*/ jsx_runtime.jsx("div", {
                                                    className: "offcanvas",
                                                    children: /*#__PURE__*/ jsx_runtime.jsx("button", {
                                                        className: "menu-bars flex text-white text-[24px]",
                                                        "aria-label": "Right Align",
                                                        children: /*#__PURE__*/ jsx_runtime.jsx(fa_.FaBars, {
                                                            onClick: showOffcanvas
                                                        })
                                                    })
                                                })
                                            })
                                        ]
                                    })
                                })
                            ]
                        })
                    })
                })
            }),
            /*#__PURE__*/ jsx_runtime.jsx("div", {
                className: offcanvas ? "offcanvas-menu-wrap active" : "offcanvas-menu-wrap",
                children: /*#__PURE__*/ jsx_runtime.jsx("nav", {
                    className: "offcanvas-menu",
                    children: /*#__PURE__*/ (0,jsx_runtime.jsxs)("ul", {
                        className: "offcanvas-menu-items",
                        onClick: showOffcanvas,
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime.jsxs)("li", {
                                className: "navbar-toggle flex justify-between items-center pb-[15px]",
                                children: [
                                    /*#__PURE__*/ jsx_runtime.jsx("div", {
                                        className: "logo",
                                        children: /*#__PURE__*/ jsx_runtime.jsx((link_default()), {
                                            href: "/",
                                            children: /*#__PURE__*/ jsx_runtime.jsx((image_default()), {
                                                src: "/images/logo/logo-footer.webp",
                                                alt: "Logo",
                                                width: 150,
                                                height: 50
                                            })
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime.jsx("button", {
                                        className: "menu-bars text-[24px] opacity-80 hover:opacity-50 transition-all",
                                        "aria-label": "Right Align",
                                        children: /*#__PURE__*/ jsx_runtime.jsx(ai_.AiOutlineClose, {})
                                    })
                                ]
                            }),
                            offcanvas_data/* OffcanvasData */.A.map((item, index)=>{
                                return /*#__PURE__*/ jsx_runtime.jsx("li", {
                                    className: item.cName,
                                    children: /*#__PURE__*/ jsx_runtime.jsx((link_default()), {
                                        href: "#",
                                        children: item.title
                                    })
                                }, index);
                            })
                        ]
                    })
                })
            })
        ]
    });
}
/* harmony default export */ const header_1 = (HeaderOne);


/***/ }),

/***/ 6811:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   A: () => (/* binding */ OffcanvasData)
/* harmony export */ });
// offcanvas-data.js
const OffcanvasData = [
    {
        title: "Home",
        path: "/",
        cName: "offcanvas-text"
    },
    {
        title: "About",
        path: "/about",
        cName: "offcanvas-text"
    },
    {
        title: "Services",
        cName: "offcanvas-text dropdown",
        subcategories: [
            {
                title: "Residential Services",
                path: "/services/residential",
                subServices: [
                    // Add 12 services for Residential Services
                    {
                        title: "Appliance Removal",
                        description: "No More Clutter: Junk Appliance Removal Services in Albuquerque",
                        path: "/services/residential/applianceremoval"
                    },
                    {
                        title: "Backyard Junk Removal",
                        description: "Reclaim Your Place with Expert Backyard Trash Removal Albuquerque",
                        path: "/services/residential/backyardjunkremoval"
                    },
                    {
                        title: "Cement and Asphalt Removal",
                        description: "Effortless Cement and Asphalt Removal for Clear Surfaces",
                        path: "/services/residential/cementandasphaltremoval"
                    },
                    {
                        title: "Cinder Block Removal",
                        description: "Smart & Efficient Cinder Block Removal in Albuquerque NM",
                        path: "/services/residential/cinderblockremoval"
                    },
                    {
                        title: "Couch Removal",
                        description: "Farewell to Your Old Couch in Albuquerque with Zia Later",
                        path: "/services/residential/couchremoval"
                    },
                    {
                        title: "Furniture Removal",
                        description: "Streamline Your Space with Professional Old Furniture Removal in Albuquerque",
                        path: "/services/residential/furnitureremoval"
                    },
                    {
                        title: "Hoarder Cleanups",
                        description: "Compassionate Hoarder Junk Cleanup in Albuquerque for a Fresh Startup",
                        path: "/services/residential/hoardercleanups"
                    },
                    {
                        title: "Hot Tub Removal",
                        description: "Effortless Hot Tub Removal and Disposal service Albuquerque",
                        path: "/services/residential/hottubremoval"
                    },
                    {
                        title: "Home Remodel Junk Removal",
                        description: "Streamline Your Home Remodel with Expert Junk Removal",
                        path: "/services/residential/homeremodeljunkremoval"
                    },
                    {
                        title: "Mattress Removal",
                        description: "Hassle-Free Mattress removal Service in Albuquerque",
                        path: "/services/residential/mattressremoval"
                    },
                    {
                        title: "Shed Junk Removal",
                        description: "Clear Your Space and Restore Order with Shed Junk Removal Services in Albuquerque",
                        path: "/services/residential/shedjunkremoval"
                    },
                    {
                        title: "Wood Removal",
                        description: "Effortless Wood Removal Services Albuquerque for a Clutter-Free Space",
                        path: "/services/residential/woodremoval"
                    },
                    {
                        title: "Tree and Branch Removal",
                        description: "Efficient Branch and Tree Removal Service Albuquerque",
                        path: "/services/residential/treeandbranchremoval"
                    },
                    {
                        title: "Yard Debris and Yard Waste Removal",
                        description: "Transform Your Yard with Our Expert Debris and Waste Removal Service",
                        path: "/services/residential/yarddebrisandyardwasteremoval"
                    }
                ]
            },
            {
                title: "Commercial Services",
                path: "/services/commercial",
                subServices: [
                    // Add 12 services for Residential Services
                    {
                        title: "Cardboard Removal",
                        description: "Effortless Cardboard Removal Service in Albuquerque",
                        path: "/services/commercial/cardboardremoval"
                    },
                    {
                        title: "Construction Waste Removal",
                        description: "Efficient Construction Waste Removal Service in Albuquerque",
                        path: "/services/commercial/constructionwasteremoval"
                    },
                    {
                        title: "Dumpster Cleanouts",
                        description: "Make Your Disposal Hassle-free with Professional Trash Dumpster Rental Service.",
                        path: "/services/commercial/dumpstercleanouts"
                    },
                    {
                        title: "Metal Recycling",
                        description: "Maximize Sustainability with Expert Metal Recycling Services",
                        path: "/services/commercial/metalrecycling"
                    },
                    {
                        title: "Office Cleanouts",
                        description: "Efficient Office Cleanouts for a Productive Workspace",
                        path: "/services/commercial/officecleanouts"
                    },
                    {
                        title: "Pallet Removal",
                        description: "Efficient Pallet Removal for Clear and Functional Spaces",
                        path: "/services/commercial/palletremoval"
                    },
                    {
                        title: "Recycling Services",
                        description: "Promoting Sustainability with Reliable Recycling Services",
                        path: "/services/commercial/recyclingservices"
                    },
                    {
                        title: "Shipping Container Cleanouts",
                        description: "Efficient Cleanouts for Clear and Functional Shipping Containers",
                        path: "/services/commercial/shippingcontainercleanouts"
                    },
                    {
                        title: "Senior Home Junk Removal",
                        description: "Compassionate Home Junk Removal for Safe and Comfortable",
                        path: "/services/commercial/seniorhomejunkremoval"
                    },
                    {
                        title: "Restaurant Cleanouts",
                        description: "Streamline Your Restaurant with Expert Cleanout Services",
                        path: "/services/commercial/restaurantcleanouts"
                    },
                    {
                        title: "Trash Removal",
                        description: "Effortless Trash Removal for Clean and Tidy Spaces",
                        path: "/services/commercial/trashremoval"
                    },
                    {
                        title: "Tire Removal",
                        description: "Efficient Tire Removal & Disposal Services in Albuquerque NM",
                        path: "/services/commercial/tireremoval"
                    },
                    {
                        title: "Warehouse Cleanouts",
                        description: "Efficient Warehouse Cleanouts for Organized and Productive Spaces",
                        path: "/services/commercial/warehousecleanouts"
                    }
                ]
            },
            {
                title: "Realtor Services",
                path: "/services/realtor",
                subServices: [
                    // Add 12 services for Residential Services
                    {
                        title: "Apartment Cleanouts",
                        description: "Hassle-free Apartment Cleanouts Services Albuquerque",
                        path: "/services/realtor/apartmentcleanouts"
                    },
                    {
                        title: "Foreclosure Junk Removal",
                        description: "Swift Foreclosure Junk Removal to Simplify Property Transitions",
                        path: "/services/realtor/foreclosurejunkremoval"
                    },
                    {
                        title: "Garage Cleanouts",
                        description: "Clean Out Your Garage and Transform It into a Relaxing Oasis",
                        path: "/services/realtor/garagecleanouts"
                    },
                    {
                        title: "Hoarder Junk Removal",
                        description: "Compassionate Hoarder Junk Removal for a Fresh Start",
                        path: "/services/realtor/hoarderjunkremoval"
                    },
                    {
                        title: "Rental Property Junk Removal",
                        description: "Effortless Junk Removal Solutions for Rental Property Owners",
                        path: "/services/realtor/rentalpropertyjunkremoval"
                    },
                    {
                        title: "Tenant Junk Removal",
                        description: "Reliable junk removal services for satisfied tenants every time",
                        path: "/services/realtor/tenantjunkremoval"
                    }
                ]
            }
        ]
    },
    {
        title: "Reviews",
        path: "/reviews",
        cName: "offcanvas-text"
    },
    {
        title: "Request quote",
        path: "/request-quote",
        cName: "offcanvas-text"
    },
    {
        title: "Contact",
        path: "/contact",
        cName: "offcanvas-text"
    }
];


/***/ })

};
;